library(testthat)
library(shinyValidatorDummy)

test_check("shinyValidatorDummy")
